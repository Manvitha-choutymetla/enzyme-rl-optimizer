import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
from pathlib import Path

# Step 1: Load the local dataset with robust sheet detection
file_path = Path('./Main_dataset_v1.xlsx')  # Update if needed
excel_file = pd.ExcelFile(file_path)

print("Available sheets:")
print(excel_file.sheet_names)

# Loop to find k_cat sheet
kcat_sheet = None
for sheet in excel_file.sheet_names:
    if any(keyword in sheet.lower() for keyword in ['kcat', 'turnover', 'cat']):
        kcat_sheet = sheet
        break

if kcat_sheet is None:
    print("\nAuto-detection failed. Checking columns in each sheet...")
    for sheet in excel_file.sheet_names:
        temp_df = pd.read_excel(file_path, sheet_name=sheet)
        if 'kcat_value (1/s)' in temp_df.columns:  # Updated to match actual column
            kcat_sheet = sheet
            print(f"Found k_cat data in sheet: '{sheet}'")
            break
    if kcat_sheet is None:
        raise ValueError("No k_cat sheet found. Manually set sheet_name below.")

print(f"\nLoading k_cat data from sheet: '{kcat_sheet}'")

df = pd.read_excel(file_path, sheet_name=kcat_sheet)

print(f"Dataset shape: {df.shape}")
print("\nColumn names:")
print(df.columns.tolist())
print("\nFirst few rows:")
print(df.head(3))  # Show 3 rows for Mutant value check

# Quick check for key columns (updated names)
required_cols = ['kcat_value (1/s)', 'pH', 'Temperature', 'EC_number', 'UniProt_ID', 'Substrate_SMILES', 'Mutant']
missing = [col for col in required_cols if col not in df.columns]
if missing:
    print(f"\nWarning: Missing columns: {missing} in '{kcat_sheet}'. Try another sheet or check file.")
    # Print Mutant values if column exists
    if 'Mutant' in df.columns:
        print(f"Sample Mutant values: {df['Mutant'].unique()[:5]}")
    # Stop here if critical missing
    if 'kcat_value (1/s)' not in df.columns:
        raise ValueError("Critical: 'kcat_value (1/s)' missing. Verify file/sheet.")
else:
    print("\nAll key columns found—proceeding.")

# Step 2: Data Cleaning (only if columns present)
if all(col in df.columns for col in required_cols):
    # Check Mutant values and filter accordingly (based on your print: 'no' for WT)
    print(f"\nUnique Mutant values: {df['Mutant'].unique()}")
    df = df[df['Mutant'] == 'no'].copy()  # String 'no' for WT
    
    key_cols = ['kcat_value (1/s)', 'pH', 'Temperature']
    df = df.dropna(subset=key_cols)

    # Rename kcat column for simplicity
    df = df.rename(columns={'kcat_value (1/s)': 'kcat_value'})

    # Coerce pH to numeric, handling placeholders like '-----'
    df['pH'] = pd.to_numeric(df['pH'], errors='coerce')

    # Clean Temperature: Extract numeric value from strings like '37°C'
    df['Temperature'] = df['Temperature'].astype(str).str.extract(r'(\d+\.?\d*)').astype(float)
    df = df.dropna(subset=['Temperature', 'pH'])  # Drop NaNs after parsing/coercing

    # Log-transform kcat_value
    df['log_kcat'] = np.log10(df['kcat_value'].clip(lower=1e-6))

    # Add substrate feature (safe len for NaN/empty)
    df['smiles_length'] = df['Substrate_SMILES'].fillna('').astype(str).str.len()

    print(f"\nAfter cleaning (WT only): {len(df)} rows")
    print(f"EC classes distribution (top 5):\n{df['EC_number'].value_counts().head()}")
else:
    print("\nSkipping cleaning due to missing columns. Fix sheet/file.")
    # For testing, you can comment out the raise above and proceed with partial data

# Step 3: Select Enzymes with Variation (skip if df empty)
if len(df) == 0:
    print("No data after cleaning—check Mutant filter (e.g., try == 'yes' or remove filter).")
else:
    enzyme_counts = df.groupby('UniProt_ID').size()
    candidate_enzymes = enzyme_counts[enzyme_counts > 20].index.tolist()
    print(f"\nCandidates with >20 points: {len(candidate_enzymes)}")

    # Filter to enzymes with variation in pH or Temperature (std > 0)
    varying_enzymes = []
    for e in candidate_enzymes:
        sub_df = df[df['UniProt_ID'] == e]
        if sub_df['pH'].std() > 0 or sub_df['Temperature'].std() > 0:
            varying_enzymes.append(e)

    print(f"Enzymes with variation in pH/Temp: {len(varying_enzymes)}")

    if len(varying_enzymes) == 0:
        print("No varying enzymes >20 points—lowering to 10.")
        candidate_enzymes = enzyme_counts[enzyme_counts > 10].index.tolist()
        for e in candidate_enzymes:
            sub_df = df[df['UniProt_ID'] == e]
            if sub_df['pH'].std() > 0 or sub_df['Temperature'].std() > 0:
                varying_enzymes.append(e)

    if len(varying_enzymes) > 0:
        selected_enzyme = varying_enzymes[0]  # Pick first varying
        enzyme_df = df[df['UniProt_ID'] == selected_enzyme].copy()
        print(f"\nSelected enzyme (with variation): {selected_enzyme}")
        print(f"EC: {enzyme_df['EC_number'].iloc[0]}")
        print(f"Data points: {len(enzyme_df)}")
        print(f"pH std: {enzyme_df['pH'].std():.3f}, Temp std: {enzyme_df['Temperature'].std():.3f}")
        print(enzyme_df[['pH', 'Temperature', 'smiles_length', 'log_kcat']].head())

        # Step 4: Prepare Features and Target
        feature_cols = ['pH', 'Temperature', 'smiles_length']
        X = enzyme_df[feature_cols]
        y = enzyme_df['log_kcat']

        # Scale features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        # Step 5: Train-Test Split
        X_train, X_test, y_train, y_test = train_test_split(
            X_scaled, y, test_size=0.2, random_state=42
        )

        # Step 6: Train Random Forest Model
        model = RandomForestRegressor(
            n_estimators=200,
            max_depth=10,
            random_state=42
        )
        model.fit(X_train, y_train)

        # Predictions
        y_pred_train = model.predict(X_train)
        y_pred_test = model.predict(X_test)

        # Metrics
        train_r2 = r2_score(y_train, y_pred_train)
        test_r2 = r2_score(y_test, y_pred_test)
        train_rmse = np.sqrt(mean_squared_error(y_train, y_pred_train))
        test_rmse = np.sqrt(mean_squared_error(y_test, y_pred_test))

        print(f"\n--- Model Performance ---")
        print(f"Train R²: {train_r2:.3f} | RMSE: {train_rmse:.3f}")
        print(f"Test R²: {test_r2:.3f} | RMSE: {test_rmse:.3f}")

        # Cross-validation
        cv_scores = cross_val_score(model, X_scaled, y, cv=5, scoring='r2')
        print(f"5-Fold CV R²: {cv_scores.mean():.3f} ± {cv_scores.std():.3f}")

        # Feature Importance
        importances = pd.DataFrame({
            'feature': feature_cols,
            'importance': model.feature_importances_
        }).sort_values('importance', ascending=False)
        print(f"\nFeature Importances:\n{importances}")

        # Step 7: Visualizations
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))

        # 1. Actual vs Predicted (Test Set)
        axes[0, 0].scatter(y_test, y_pred_test, alpha=0.7, color='blue')
        axes[0, 0].plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--', lw=2)
        axes[0, 0].set_xlabel('Actual log(k_cat)')
        axes[0, 0].set_ylabel('Predicted log(k_cat)')
        axes[0, 0].set_title(f'Test Set: R² = {test_r2:.3f}')

        # 2. Residuals Plot
        residuals = y_test - y_pred_test
        axes[0, 1].scatter(y_pred_test, residuals, alpha=0.7, color='green')
        axes[0, 1].axhline(y=0, color='r', linestyle='--')
        axes[0, 1].set_xlabel('Predicted log(k_cat)')
        axes[0, 1].set_ylabel('Residuals')
        axes[0, 1].set_title('Residuals Plot')

        # 3. pH vs log_kcat (Actual vs Predicted)
        axes[1, 0].scatter(enzyme_df['pH'], enzyme_df['log_kcat'], alpha=0.6, label='Actual', color='blue')
        pred_ph = np.concatenate([X_train[:, 0], X_test[:, 0]])
        full_pred = np.concatenate([y_pred_train, y_pred_test])
        axes[1, 0].scatter(pred_ph, full_pred, alpha=0.6, label='Predicted', color='orange')
        axes[1, 0].set_xlabel('pH')
        axes[1, 0].set_ylabel('log(k_cat)')
        axes[1, 0].set_title('Activity vs pH')
        axes[1, 0].legend()

        # 4. Heatmap of Feature Importances
        sns.heatmap(importances.set_index('feature').T, annot=True, cmap='Blues', ax=axes[1, 1])
        axes[1, 1].set_title('Feature Importances')

        plt.tight_layout()
        plt.show()

        # Step 8: Optional - Global Model (with extra cleaning)
        print("\n--- Global Model (All Enzymes) ---")
        # Extra coerce for safety
        global_df = df[feature_cols + ['log_kcat']].copy()
        for col in ['pH', 'Temperature']:
            global_df[col] = pd.to_numeric(global_df[col], errors='coerce')
        global_df = global_df.dropna()
        if len(global_df) > 100:
            global_X = scaler.fit_transform(global_df[feature_cols])
            global_y = global_df['log_kcat']
            global_model = RandomForestRegressor(n_estimators=200, max_depth=10, random_state=42)
            global_cv = cross_val_score(global_model, global_X, global_y, cv=3, scoring='r2')
            print(f"Global 3-Fold CV R²: {global_cv.mean():.3f} ± {global_cv.std():.3f}")
        else:
            print("Insufficient data for global model.")

        # Step 9: Save Model and Scaler
        joblib.dump(model, 'per_enzyme_model.pkl')
        joblib.dump(scaler, 'feature_scaler.pkl')
        print("\nModels and scaler saved!")

        # Step 10: Example Prediction Function
        def predict_activity(ph, temp, smiles_length, model=model, scaler=scaler):
            input_features = np.array([[ph, temp, smiles_length]])
            input_scaled = scaler.transform(input_features)
            log_kcat_pred = model.predict(input_scaled)[0]
            k_cat_pred = 10 ** log_kcat_pred
            return k_cat_pred

        example_kcat = predict_activity(ph=7.0, temp=37.0, smiles_length=10)
        print(f"\nExample: Predicted k_cat at pH=7, Temp=37°C, SMILES len=10: {example_kcat:.2f} s⁻¹")
    else:
        print("No suitable enzymes with variation found. Try lowering threshold or check data.")